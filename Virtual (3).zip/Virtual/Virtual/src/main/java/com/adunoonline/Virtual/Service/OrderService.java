package com.adunoonline.Virtual.Service;

import com.adunoonline.Virtual.Model.Card;
import com.adunoonline.Virtual.Model.Order;
import com.adunoonline.Virtual.Model.PaymentDto.PaymentDto;
import com.adunoonline.Virtual.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    public List<PaymentDto> getOrders(){

        return orderRepository.findAll()
                .stream()
                .map(this::OrderPaymentDTO)
                .collect(Collectors.toList());
    }
    public PaymentDto OrderPaymentDTO(Order order){
        PaymentDto order1 = new PaymentDto();
        order1.setOrderNumber(order.getOderNumber());
        order1.setAmount(order.getAmount());
        order1.setQuantity(order.getQuantity());
        order1.setTotal(order.getTotal());
   //     order1.setExpiryDate(order.getExpiryDate());

        return order1;
    }

     public Order newOrder(Order order){
         System.out.println("New Order Created Successfully " + order);
          return orderRepository.save(order);
    }

}
