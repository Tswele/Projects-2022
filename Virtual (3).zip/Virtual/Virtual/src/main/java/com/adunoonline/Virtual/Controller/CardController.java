package com.adunoonline.Virtual.Controller;

import com.adunoonline.Virtual.Model.Card;
import com.adunoonline.Virtual.Model.PaymentDto.PaymentDto;
import com.adunoonline.Virtual.Service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin()
@RequestMapping("/card/v1")
public class CardController {

    private CardService cardService;

    @Autowired
    public CardController(CardService cardService) {

        this.cardService = cardService;
    }

    @GetMapping("/allcards")
    public List<PaymentDto> getCards(){
        return cardService.getCards();
    }
    @PostMapping("/NewCard")
    public ResponseEntity<Card> newCard(@RequestBody Card card){
        return ResponseEntity.ok(cardService.newCard(card));
    }
}
