package com.adunoonline.Virtual.Service;

import com.adunoonline.Virtual.Model.Card;
import com.adunoonline.Virtual.Model.PaymentDto.PaymentDto;
import com.adunoonline.Virtual.Repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CardService {
    @Autowired
    private CardRepository cardrepository;

    public List<PaymentDto> getCards(){

       return cardrepository.findAll()
               .stream()
               .map(this::CardPaymentDTO)
               .collect(Collectors.toList());
    }
    public PaymentDto CardPaymentDTO(Card card){
        PaymentDto card1 = new PaymentDto();
        card1.setCardNo(card.getCardNo());
        card1.setCardHolder(card.getCardHolder());
        card1.setCardType(card.getCardType());
        card1.setCvv(card.getCvv());
        card1.setExpiryDate(card.getExpiryDate());

        return card1;
    }

    public Card newCard(Card card) {
        System.out.println("New Card Created");
        return cardrepository.save(card);
    }
}
