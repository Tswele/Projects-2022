package com.adunoonline.Virtual.Controller;

import com.adunoonline.Virtual.Model.Order;
import com.adunoonline.Virtual.Model.PaymentDto.PaymentDto;
import com.adunoonline.Virtual.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Order")

public class OrderController {
    private final OrderService orderService;
    @Autowired
    OrderController(OrderService orderService){
        this.orderService = orderService;
    }

    @GetMapping("/getOrders")
    public List<PaymentDto> getOrders()
    {
        return orderService.getOrders();
    }

    @PostMapping("/newOrder")
    public ResponseEntity<Order> newOrder(@RequestBody Order order){

     return   ResponseEntity.ok( orderService.newOrder(order));
}
}
