package com.adunoonline.Virtual.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name ="Users")

public class Users {

    @Id
    @GeneratedValue( strategy = GenerationType.AUTO)
    private Integer ID;
    private String iss;
    private String cuid;
    private String auid;
    private String reference;
    private String amount;
    private String username;
    private String Password;

}
