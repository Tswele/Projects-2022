package com.adunoonline.Virtual.Controller;

import com.adunoonline.Virtual.Model.Address;
import com.adunoonline.Virtual.Service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@CrossOrigin()
@RequestMapping("/Address/v1")
public class AddressController {

    private AddressService addressService;
    @Autowired
    public AddressController(AddressService addressService) {
        this.addressService = addressService;
    }

    @GetMapping("/getAddress")
   public List<Address> getAddress(){
        return addressService.getAddress();
    }
    @PostMapping("/newAddress")
    public Address newAddress(@RequestBody Address address){
        return addressService.newAddress(address);
        }
}
