package com.adunoonline.Virtual;

import com.adunoonline.Virtual.Model.*;
import com.adunoonline.Virtual.Repository.AddressRepository;
import com.adunoonline.Virtual.Repository.CardRepository;
import com.adunoonline.Virtual.Repository.MerchantDetailsRepository;
import com.adunoonline.Virtual.Repository.OrderRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.List;

@Configuration
public class CardConfig {

    @Bean
    CommandLineRunner commandLineRunner(CardRepository cardRepository, OrderRepository orderRepository, AddressRepository addressRepository, MerchantDetailsRepository merchantDetailsRepository){
        return agrs -> {
             //Card command
            Card mastercard = new Card(11223232l,"Mr B Shangase",123, LocalDate.of(2002,05,01), CardType.CREDIT_CARD);

             Card visa       = new Card(23245545l,"Mr Adumo",124, LocalDate.of(2001,04,01), CardType.VISA_CHECKOUT);
            cardRepository.saveAll(List.of(mastercard,visa));
            //Order command
            Order Order1 = new Order(1223232l,2,20.0,40.0);

            Order Order2 = new Order(432323l,3,10.0,30.0);
            orderRepository.saveAll(List.of(Order1, Order2));

            //Address command
            Address brixton = new Address(1212l,"Huntley","Brixton", " South Africa",null,null,null);

            Address Auckland = new Address(53212l,"Kingsway","AucklandPark", " South Africa",null,null,null);

            addressRepository.saveAll(List.of(brixton, Auckland));


            //User commands
            Users user1 = new Users(3,"9BA5008C-08EE-4286-A349-54AF91A621B0","4196B0B8-DB88-42E5-A06D-294A5E4DED87","Dev Center","2","Adumo_ref","musa1","123");

            Users user2 = new Users(4,"9BA5008C-08EE-4286-A349-54AF91A621B0","4196B0B8-DB88-42E5-A06D-294A5E4DED87","Dev Center","3","Dev_Merch","adumo11","123");

            merchantDetailsRepository.saveAll(List.of(user1,user2));

        };

        }
}
