package com.adunoonline.Virtual.Repository;

import com.adunoonline.Virtual.Model.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantDetailsRepository extends JpaRepository<Users,Integer> {
    org.springframework.security.core.userdetails.User findByUsername(String userName);
}
