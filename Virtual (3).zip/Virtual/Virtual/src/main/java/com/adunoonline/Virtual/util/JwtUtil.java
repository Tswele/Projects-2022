package com.adunoonline.Virtual.util;

import com.adunoonline.Virtual.Model.AuthenticationRequest;
import com.adunoonline.Virtual.Model.Users;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtUtil {
    private String SECRETE_KEY = "4b4c5mkm1ioBsU3RvhvzSsdtg3m7I8Y0ybZWRGderIsbdoQWqGhc2iiK";


    public String extractUsername(String token){
        return extractClaim(token, Claims::getSubject);
    }

    //check if the token has expired

    public Date extractExpiration(String token){
        return extractClaim(token, Claims::getExpiration);
    }
    public <T> T extractClaim(String token, Function<Claims,T> claimsResolver){
        final Claims claims= extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    //for retrieveing any information from token we will need the secret key

    private Claims extractAllClaims(String token){
        return Jwts.parser().setSigningKey(SECRETE_KEY).parseClaimsJws(token).getBody();
    }

    private Boolean isTokenExpired(String token){
        return extractExpiration(token).before(new Date());
    }
    public String generateToken(UserDetails userDetails, AuthenticationRequest authenticationRequest){

        Map<String,Object> claims = new HashMap<>();

//        claims.put("cuid", users.getCuid());
//        claims.put("auid", users.getAuid());
//       // claims.put("iss", "Dev Center");
//        claims.put("mref", users.getReference());
//        claims.put("amount",users.getAmount());


        claims.put("cuid", authenticationRequest.getCuid().trim());
        claims.put("auid", authenticationRequest.getAuid().trim());
       // claims.put("iss", "Dev Center");
        claims.put("mref", authenticationRequest.getReference().trim());
        claims.put("amount",authenticationRequest.getAmount().trim());




        return createToken(claims,userDetails.getUsername());

    }
    private String createToken(Map<String,Object> claims, String subject){
        byte[] bytes =SECRETE_KEY.getBytes();
        //System.out.println(""+bytes.length);
        Key secretKey = Keys.hmacShaKeyFor(bytes);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject).setHeaderParam("typ","JWT")
                .setIssuedAt(new Date(System.currentTimeMillis()- 60 * 60))
                .setExpiration(new Date(System.currentTimeMillis()+ 1000 * 60 * 60 * 10))
                .signWith(secretKey,SignatureAlgorithm.HS256).compact();
    }

    //validate token

    public Boolean validateToken(String token,UserDetails userDetails){
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }


}
