package com.adunoonline.Virtual.Model;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;


@Entity
@Table(name = "card")
public class Card {

    @Id()
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long cardNo ;
    private String cardHolder;
    private Integer cvv;
    private LocalDate expiryDate;
    private CardType cardType;

    public Card() {
    }

    public Card(Long cardNo, String cardHolder, Integer cvv, LocalDate expiryDate, CardType cardType) {
        this.cardNo = cardNo;
        this.cardHolder = cardHolder;
        this.cvv = cvv;
        this.expiryDate = expiryDate;
        this.cardType = cardType;
    }

    public Long getCardNo() {
        return cardNo;
    }

    public void setCardNo(Long cardNo) {
        this.cardNo = cardNo;
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public Integer getCvv() {
        return cvv;
    }

    public void setCvv(Integer cvv) {
        this.cvv = cvv;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public CardType getCardType() {
        return cardType;
    }

    public void setCardType(CardType cardType) {
        this.cardType = cardType;
    }

    @Override
    public String toString() {
        return "Card{" +
                "cardNo=" + cardNo +
                ", cardHolder='" + cardHolder + '\'' +
                ", cvv=" + cvv +
                ", expiryDate=" + expiryDate +
                ", cardType=" + cardType +
                '}';
    }
}
