package com.adunoonline.Virtual.Model.PaymentDto;
import com.adunoonline.Virtual.Model.CardType;

import java.time.LocalDate;
import java.util.Date;

public class PaymentDto {
        private long cardNo;
        private String cardHolder;
        private Integer cvv;
        private LocalDate expiryDate;
        private CardType cardType;
        private long orderNumber;
        private Integer quantity;
        private double amount;
        private double total;

        public long getCardNo() {
            return cardNo;
        }

        public void setCardNo(long cardNo) {
            this.cardNo = cardNo;
        }

        public String getCardHolder() {
            return cardHolder;
        }

        public void setCardHolder(String cardHolder) {
            this.cardHolder = cardHolder;
        }

        public Integer getCvv() {
            return cvv;
        }

        public void setCvv(Integer cvv) {
            this.cvv = cvv;
        }

        public LocalDate getExpiryDate() {
            return expiryDate;
        }

        public void setExpiryDate(LocalDate expiryDate) {
            this.expiryDate = expiryDate;
        }

        public CardType getCardType() {
            return cardType;
        }

        public void setCardType(CardType cardType) {
            this.cardType = cardType;
        }

        public long getOrderNumber() {
            return orderNumber;
        }

        public void setOrderNumber(long orderNumber) {
            this.orderNumber = orderNumber;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }

        public double getAmount() {
            return amount;
        }

        public void setAmount(double amount) {
            this.amount = amount;
        }

        public double getTotal() {
            return total;
        }

        public void setTotal(double total) {
            this.total = total;
        }
    }


