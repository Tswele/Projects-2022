package com.adunoonline.Virtual.Service;

import com.adunoonline.Virtual.Model.Users;
import com.adunoonline.Virtual.Model.PaymentDto.PaymentDto;
import com.adunoonline.Virtual.Repository.MerchantDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


import java.util.ArrayList;

@Service
public class MerchantDetailService implements UserDetailsService {
    @Autowired
    private MerchantDetailsRepository merchantDetailsRepository;
/*
    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
      User user = merchantDetailsRepository.findByUsername(userName);
        return new User(user.getUsername(),user.getPassword(),new ArrayList<>());
    }*/

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        return new User("Adumo11","123",new ArrayList<>());
    }

    public Users saveMerchantDetail(Users user){
        return merchantDetailsRepository.save(user);
    }


}
