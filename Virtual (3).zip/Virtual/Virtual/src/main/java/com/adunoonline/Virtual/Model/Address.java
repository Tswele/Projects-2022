package com.adunoonline.Virtual.Model;

import org.yaml.snakeyaml.events.Event;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name = "Address")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long addressNo;
    private String streetName;
    private String suburb;
    private String country;
    private String AddressLine1;
    private String AddressLine2;
    private String AddressLine3;

    public Address() {
    }

    public Address(Long addressNo, String streetName, String suburb, String country, String addressLine1, String addressLine2, String addressLine3) {
        this.addressNo = addressNo;
        this.streetName = streetName;
        this.suburb = suburb;
        this.country = country;
        AddressLine1 = addressLine1;
        AddressLine2 = addressLine2;
        AddressLine3 = addressLine3;
    }

    public Long getAddressNo() {
        return addressNo;
    }

    public void setAddressNo(Long addressNo) {
        this.addressNo = addressNo;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getSuburb() {
        return suburb;
    }

    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAddressLine1() {
        return AddressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        AddressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return AddressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        AddressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return AddressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        AddressLine3 = addressLine3;
    }

    @Override
    public String toString() {
        return "Address{" +
                "addressNo=" + addressNo +
                ", streetName='" + streetName + '\'' +
                ", suburb='" + suburb + '\'' +
                ", country='" + country + '\'' +
                ", AddressLine1='" + AddressLine1 + '\'' +
                ", AddressLine2='" + AddressLine2 + '\'' +
                ", AddressLine3='" + AddressLine3 + '\'' +
                '}';
    }
}
