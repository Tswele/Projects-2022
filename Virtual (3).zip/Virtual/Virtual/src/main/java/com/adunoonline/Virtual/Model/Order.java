package com.adunoonline.Virtual.Model;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
@Entity(name = "Orders")
@Table()
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long oderNumber;
    private Integer quantity;
    private Double Amount;
    private Double Total;
   // @OneToMany
  //  private List<String> description;

    public Order() {
    }

    public Order(Long oderNumber, Integer quantity, Double amount, Double total) {
        this.oderNumber = oderNumber;
        this.quantity = quantity;
        Amount = amount;
        Total = total;
       // this.description = new ArrayList<>();
    }

    public Long getOderNumber() {
        return oderNumber;
    }

    public void setOderNumber(Long oderNumber) {
        this.oderNumber = oderNumber;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Double getAmount() {
        return Amount;
    }

    public void setAmount(Double amount) {
        Amount = amount;
    }

    public Double getTotal() {
        return Total;
    }

    public void setTotal(Double total) {

        Total = total;
    }
/*
    public List<String> getDescription() {
        return null;new ArrayList<>(description);
    }

    public void setDescription(List<String> description) {
        this.description = (description== null)? new ArrayList<>() : new ArrayList<>();
    }*/
//@Order
    @Override
    public String toString() {
        return "Order{" +
                "oderNumber=" + oderNumber +
                ", quantity=" + quantity +
                ", Amount=" + Amount +
                ", Total=" + Total +
              // ", description=" + description +
                '}';
    }
}
