package com.adunoonline.Virtual.Model;

public enum CardType {

        DEBIT_CARD,
        CREDIT_CARD,
        VISA_CHECKOUT,
        MOBICRED,
        SECURE_EFT

}
